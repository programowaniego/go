#ifndef SZASZORY_GENERATOR_RUCHOW

#define SZASZORY_GENERATOR_RUCHOW
#include"szaszory.lista.ruchow.h"

int sign(int x)
{
    return x ? ((x > 0) ? 1 : -1) : 0;
}

boolean czynaszachownicy(int ind)
{
    return (ind >= 0) && (ind < 8);
}

boolean czypolejestnaszachownicy(int wiersz, int kolumna)
{
    return czynaszachownicy(wiersz) && czynaszachownicy(kolumna);
}

int kierunkow[] = {4, 8, 4, 8, 8};
int ***przyrosty = (int**[]) 
{ 
    //goniec
    (int*[]){ (int[]){1, 1, 8}, (int[]){-1, -1, 8}, (int[]){1, -1, 8}, (int[]){-1, 1, 8} },
    //skoczek
    (int*[]){ (int[]){2, 1, 1}, (int[]){2, -1, 1}, (int[]){-2, -1, 1}, (int[]){-2, 1, 1}, (int[]){1, 2, 1}, (int[]){-1, 2, 1}, (int[]){-1, -2, 1}, (int[]){1, -2, 1} },
    //wieza
    (int*[]){ (int[]){1, 0, 8}, (int[]){-1, 0, 8}, (int[]){0, -1, 8}, (int[]){0, 1, 8} },
    //hetman
    (int*[]){ (int[]){1, 1, 8}, (int[]){-1, -1, 8}, (int[]){1, -1, 8}, (int[]){-1, 1, 8}, (int[]){1, 0, 8}, (int[]){-1, 0, 8}, (int[]){0, -1, 8}, (int[]){0, 1, 8} },
    //krol
    (int*[]){ (int[]){1, 1, 1}, (int[]){-1, -1, 1}, (int[]){1, -1, 1}, (int[]){-1, 1, 1}, (int[]){1, 0, 1}, (int[]){-1, 0, 1}, (int[]){0, -1, 1}, (int[]){0, 1, 1} }
};

listaruchow *ruchy(listaruchow *l, szachownica *sz, ruch *r, figurka figura)
{
    for(int i = 0; i < kierunkow[abs(figura) - 2]; i++)
        for(int dw = przyrosty[abs(figura) - 2][i][0], dk = przyrosty[abs(figura) - 2][i][1], it = 0; 
        czypolejestnaszachownicy(r->z.wiersz + dw, r->z.kolumna + dk) && it < przyrosty[abs(figura) - 2][i][2]; dw += przyrosty[abs(figura) - 2][i][0], dk += przyrosty[abs(figura) - 2][i][1], it++)
        {
            if (sz->pola[r->z.wiersz + dw][r->z.kolumna + dk] * sign(figura) > 0)   
                break;
            else
            {
                r->na = pola[r->z.wiersz + dw][r->z.kolumna + dk];
                l = dodajruch(l, *r);
                if (sz->pola[r->z.wiersz + dw][r->z.kolumna + dk])
                    break;
            }
        }
    return l;
}

listaruchow *ruchypionka(listaruchow *l, szachownica *sz, ruch *r, kolorek kolor)
{
    // ruchy bez przemocy
    if (!sz->pola[r->z.wiersz + kolor][r->z.kolumna])
    {
        r->na = pola[r->z.wiersz + kolor][r->z.kolumna];
        if (r->z.wiersz != (kolor == bialy ? 6 : 1))
        { 
            l = dodajruch(l, *r);
            if (r->z.wiersz == (kolor == bialy ? 1 : 6) && !sz->pola[r->z.wiersz + 2 * kolor][r->z.kolumna])
            {
                r->na = pola[r->z.wiersz + 2 * kolor][r->z.kolumna];
                l = dodajruch(l, *r);
            }
        }
        else
        {
            r->promocja = kolor * bialy_goniec;
            for(int i = 0; i < 4; r->promocja += kolor, i++)
                l = dodajruch(l, *r);
            r->promocja = pusta;
        }
    }
    for(int dk[] = {-1, 1}, i = 0; i < 2; i++)
        // ruchy przemocowe w prawo i w lewo
        if (czynaszachownicy(r->z.kolumna + dk[i]) && (kolor * sz->pola[r->z.wiersz + kolor][r->z.kolumna + dk[i]] < 0))
        {
            r->na = pola[r->z.wiersz + kolor][r->z.kolumna + dk[i]];
            if (r->z.wiersz != (kolor == bialy ? 6 : 1))
                l = dodajruch(l, *r);
            else
            {
                r->promocja = bialy_goniec * kolor;
                for(int i = 0; i < 4; r->promocja += kolor, i++)
                    l = dodajruch(l, *r);
                r->promocja = pusta;
            }
        }
    // przemoc w locie
    if (sz->bicie_w_locie)
        for(int dk[] = {-1, 1}, i = 0; i < 2; i++)
            if (czynaszachownicy(r->z.kolumna + dk[i]) && (sz->bicie_w_locie == &pola[r->z.wiersz + kolor][r->z.kolumna + dk[i]]))
            {
                r->na = pola[r->z.wiersz + kolor][r->z.kolumna + dk[i]];
                l = dodajruch(l, *r);
            }
    return l;
}

boolean czyktosatakuje(szachownica *sz, pole *p, kolorek koloratakujacy)
{
    for(int figura = bialy_goniec; figura <= bialy_krol; figura++)
        for(int i = 0; i < kierunkow[figura - 2]; i++)
            for(int dw = przyrosty[figura - 2][i][0], dk = przyrosty[figura - 2][i][1], it = 0; 
            czypolejestnaszachownicy(p->wiersz + dw, p->kolumna + dk) && it < przyrosty[figura - 2][i][2]; dw += przyrosty[figura - 2][i][0], dk += przyrosty[figura - 2][i][1], it++)
            {
                if (sz->pola[p->wiersz + dw][p->kolumna + dk])   
                {
                    if (sz->pola[p->wiersz + dw][p->kolumna + dk] * koloratakujacy == figura)
                        return prawda;
                    break;
                }
            }
    return ((czypolejestnaszachownicy(p->wiersz - koloratakujacy, p->kolumna + 1) && sz->pola[p->wiersz - koloratakujacy][p->kolumna + 1] * koloratakujacy == bialy_pionek) || (czypolejestnaszachownicy(p->wiersz - koloratakujacy, p->kolumna - 1) && sz->pola[p->wiersz - koloratakujacy][p->kolumna - 1] * koloratakujacy == bialy_pionek));
}

listaruchow *atakujacy(szachownica *sz, pole *p, kolorek koloratakujacy)
{
    listaruchow *l = NULL;
    for(int figura = bialy_goniec; figura <= bialy_krol; figura++)
        for(int i = 0; i < kierunkow[figura - 2]; i++)
            for(int dw = przyrosty[figura - 2][i][0], dk = przyrosty[figura - 2][i][1], it = 0; 
            czypolejestnaszachownicy(p->wiersz + dw, p->kolumna + dk) && it < przyrosty[figura - 2][i][2]; dw += przyrosty[figura - 2][i][0], dk += przyrosty[figura - 2][i][1], it++)
            {
                if (sz->pola[p->wiersz + dw][p->kolumna + dk])   
                {
                    if (sz->pola[p->wiersz + dw][p->kolumna + dk] * koloratakujacy == figura)
                    {
                        ruch r = { .na = pola[p->wiersz][p->kolumna], .z = pola[p->wiersz + dw][p->kolumna + dk], .promocja = pusta };
                        l = dodajruch(l, r);
                    }
                    break;
                }
            }
    for(int dw[] = {1, -1}, i = 0; i < 2; i++)
        if (czypolejestnaszachownicy(p->wiersz - koloratakujacy, p->kolumna + dw[i]) && sz->pola[p->wiersz - koloratakujacy][p->kolumna + dw[i]] * koloratakujacy == bialy_pionek)
        {
            ruch r = { .na = pola[p->wiersz][p->kolumna], .z = pola[p->wiersz - koloratakujacy][p->kolumna + dw[i]], .promocja = pusta };
            l = dodajruch(l, r);
        }
    return l;
}

listaruchow *roszady(listaruchow *l, szachownica *sz)
{
    if ((sz->ruch == bialy ? sz->biale_krotka : sz->biale_krotka) && !sz->pola[sz->ruch == bialy ? 0 : 7][5] && !sz->pola[sz->ruch == bialy ? 0 : 7][6] && !czyktosatakuje(sz, &pola[sz->ruch == bialy ? 0 : 7][4], -sz->ruch) && !czyktosatakuje(sz, &pola[sz->ruch == bialy ? 0 : 7][5], -sz->ruch) && !czyktosatakuje(sz, &pola[sz->ruch == bialy ? 0 : 7][6], -sz->ruch))
    {
        ruch r = { .z = pola[sz->ruch == bialy ? 0 : 7][4], .na = pola[sz->ruch == bialy ? 0 : 7][6], .promocja = pusta };
        l = dodajruch(l, r);
    }
    if ((sz->ruch == bialy ? sz->biale_dluga : sz->czarne_dluga) && !sz->pola[sz->ruch == bialy ? 0 : 7][3] && !sz->pola[sz->ruch == bialy ? 0 : 7][2] && !czyktosatakuje(sz, &pola[sz->ruch == bialy ? 0 : 7][4], -sz->ruch) && !czyktosatakuje(sz, &pola[sz->ruch == bialy ? 0 : 7][3], -sz->ruch) && !czyktosatakuje(sz, &pola[sz->ruch == bialy ? 0 : 7][2], -sz->ruch))
    {
        ruch r = { .z = pola[sz->ruch == bialy ? 0 : 7][4], .na = pola[sz->ruch == bialy ? 0 : 7][2], .promocja = pusta };
        l = dodajruch(l, r);
    }
    return l;
}


listaruchow *generujruchy(szachownica *sz)
{
    listaruchow *l = NULL;
    for (int wiersz = 0; wiersz < 8; wiersz++)
        for (int kolumna = 0; kolumna < 8; kolumna++)
        {
            ruch r = { .z = pola[wiersz][kolumna], .promocja = pusta };
            if (sz->pola[wiersz][kolumna] * sz->ruch > 0)
                l = (abs(sz->pola[wiersz][kolumna]) == bialy_pionek) ? ruchypionka(l, sz, &r, sign(sz->pola[wiersz][kolumna])) : ruchy(l, sz, &r, sz->pola[wiersz][kolumna]);
        }
    l = roszady(l,sz);
    return l;
}

#endif