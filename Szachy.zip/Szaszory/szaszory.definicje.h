#ifndef SZASZORY_DEF

#define SZASZORY_DEF

typedef enum { pusta = 0, bialy_pionek = 1, bialy_goniec = 2, bialy_skoczek = 3, bialy_wieza = 4, bialy_hetman = 5, bialy_krol = 6, czarny_pionek = -1, czarny_goniec = -2, czarny_skoczek = -3, czarny_wieza = -4, czarny_hetman = -5, czarny_krol = -6 } figurka;
typedef enum { bialy = 1, czarny = -1 } kolorek;
typedef enum { falsz, prawda } boolean;

char kodyfigurek[] = "kqrnbp PBNRQK";

typedef figurka poletka[8][8];

typedef struct
{
    short int wiersz, kolumna;
} pole;

pole pola[8][8] = { { {0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {0, 5}, {0, 6}, {0, 7} }, { {1, 0}, {1, 1}, {1, 2}, {1, 3}, {1, 4}, {1, 5}, {1, 6}, {1, 7} }, { {2, 0}, {2, 1}, {2, 2}, {2, 3}, {2, 4}, {2, 5}, {2, 6}, {2, 7} }, { {3, 0}, {3, 1}, {3, 2}, {3, 3}, {3, 4}, {3, 5}, {3, 6}, {3, 7} }, { {4, 0}, {4, 1}, {4, 2}, {4, 3}, {4, 4}, {4, 5}, {4, 6}, {4, 7} }, { {5, 0}, {5, 1}, {5, 2}, {5, 3}, {5, 4}, {5, 5}, {5, 6}, {5, 7} }, { {6, 0}, {6, 1}, {6, 2}, {6, 3}, {6, 4}, {6, 5}, {6, 6}, {6, 7} }, { {7, 0}, {7, 1}, {7, 2}, {7, 3}, {7, 4}, {7, 5}, {7, 6}, {7, 7} } };

char* polastr[8][8] = { { "a1", "b1", "c1", "d1", "e1", "f1", "g1", "h1" }, { "a2", "b2", "c2", "d2", "e2", "f2", "g2", "h2" }, { "a3", "b3", "c3", "d3", "e3", "f3", "g3", "h3" }, { "a4", "b4", "c4", "d4", "e4", "f4", "g4", "h4" }, { "a5", "b5", "c5", "d5", "e5", "f5", "g5", "h5" }, { "a6", "b6", "c6", "d6", "e6", "f6", "g6", "h6" }, { "a7", "b7", "c7", "d7", "e7", "f7", "g7", "h7" }, { "a8", "b8", "c8", "d8", "e8", "f8", "g8", "h8" } };

pole fen2pole[64] = { {7, 0}, {7, 1}, {7, 2}, {7, 3}, {7, 4}, {7, 5}, {7, 6}, {7, 7}, {6, 0}, {6, 1}, {6, 2}, {6, 3}, {6, 4}, {6, 5}, {6, 6}, {6, 7}, {5, 0}, {5, 1}, {5, 2}, {5, 3}, {5, 4}, {5, 5}, {5, 6}, {5, 7}, {4, 0}, {4, 1}, {4, 2}, {4, 3}, {4, 4}, {4, 5}, {4, 6}, {4, 7}, {3, 0}, {3, 1}, {3, 2}, {3, 3}, {3, 4}, {3, 5}, {3, 6}, {3, 7}, {2, 0}, {2, 1}, {2, 2}, {2, 3}, {2, 4}, {2, 5}, {2, 6}, {2, 7}, {1, 0}, {1, 1}, {1, 2}, {1, 3}, {1, 4}, {1, 5}, {1, 6}, {1, 7}, {0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {0, 5}, {0, 6}, {0, 7} };

typedef struct 
{
    poletka pola;
    boolean czarne_dluga, czarne_krotka, biale_dluga, biale_krotka;
    pole *bicie_w_locie;
    kolorek ruch;
} szachownica;

typedef struct 
{
    pole z, na;
    figurka promocja;
    char txt[6];
} ruch;


#endif