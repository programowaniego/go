#ifndef SZASZORY_FEN

#define SZASZORY_FEN
#include<stddef.h>
#include "szaszory.definicje.h"

szachownica ustawFEN(char *fen)
{
    szachownica sz = { .pola = { pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta, pusta }, .czarne_dluga = falsz, .czarne_krotka = falsz, .biale_dluga = falsz, .biale_krotka = falsz, .bicie_w_locie = NULL };
    int sq = 0;
    while(*fen - ' ')
    {
        switch(*fen)
        {
            case '/':
                sq--;
            case ' ':
                break;
            case '1': case '2': case '3': case '4': case '5': case '6': case '7': case '8':
                sq += *fen - '0' - 1;
                break;
            case 'p': case 'P':
                sz.pola[fen2pole[sq].wiersz][fen2pole[sq].kolumna] = *fen == 'p' ? czarny_pionek : bialy_pionek;
                break;
            case 'n': case 'N':
                sz.pola[fen2pole[sq].wiersz][fen2pole[sq].kolumna] = *fen == 'n' ? czarny_skoczek : bialy_skoczek;
                break;
            case 'b': case 'B':
                sz.pola[fen2pole[sq].wiersz][fen2pole[sq].kolumna] = *fen == 'b' ? czarny_goniec : bialy_goniec;
                break;
            case 'r': case 'R':
                sz.pola[fen2pole[sq].wiersz][fen2pole[sq].kolumna] = *fen == 'r' ? czarny_wieza : bialy_wieza;
                break;
            case 'q': case 'Q':
                sz.pola[fen2pole[sq].wiersz][fen2pole[sq].kolumna] = *fen == 'q' ? czarny_hetman : bialy_hetman;
                break;
            case 'k': case 'K':
                sz.pola[fen2pole[sq].wiersz][fen2pole[sq].kolumna] = *fen == 'k' ? czarny_krol : bialy_krol;
        }
        fen++;
        sq++;
    }
    fen++;
    sz.ruch = *fen++ == 'w' ? bialy : czarny;
    fen++;
    while(*fen != ' ')
    {
        switch(*fen)
        {
            case 'K':
                sz.biale_krotka = prawda;
                break;
            case 'k':
                sz.czarne_krotka = prawda;
                break;
            case 'Q':
                sz.biale_dluga = prawda;
                break;
            case 'q':
                sz.czarne_dluga = prawda;
                break;
        }
        fen++;
    }
    if (*++fen != '-')
    {
        for(int i = 0; i < 8; i++)
        {
            if (!strcmp(polastr[2][i], fen))
            {
                sz.bicie_w_locie = &pola[2][i];
                break;
            }
            if (!strcmp(polastr[5][i], fen))
            {
                sz.bicie_w_locie = &pola[5][i];
                break;
            }
        }
    }
    return sz;
}

void wypisz(szachownica sz)
{
    printf("   +---+---+---+---+---+---+---+---+\n");
    for(int i = 7; i >= 0; i--)
    {
        printf(" %d | %c | %c | %c | %c | %c | %c | %c | %c |\n", i + 1, kodyfigurek[6 + sz.pola[i][0]], kodyfigurek[6 + sz.pola[i][1]], kodyfigurek[6 + sz.pola[i][2]], kodyfigurek[6 + sz.pola[i][3]], kodyfigurek[6 + sz.pola[i][4]], kodyfigurek[6 + sz.pola[i][5]], kodyfigurek[6 + sz.pola[i][6]], kodyfigurek[6 + sz.pola[i][7]]);
        printf("   +---+---+---+---+---+---+---+---+\n");
    }
    printf("     A   B   C   D   E   F   G   H\n\n");
    printf("    Roszady: %c%c%c%c, Ep: %s, Ruch: %c\n\n", sz.biale_dluga ? 'Q' : '-', sz.biale_krotka ? 'K' : '-', sz.czarne_dluga ? 'q' : '-', sz.czarne_krotka ? 'k' : '-', sz.bicie_w_locie ? polastr[sz.bicie_w_locie->wiersz][sz.bicie_w_locie->kolumna] : "nie", sz.ruch == bialy ? 'W' : 'B' );
}

void wypisz2(szachownica sz, szachownica sz2)
{
    printf("   +---+---+---+---+---+---+---+---+        +---+---+---+---+---+---+---+---+\n");
    for(int i = 7; i >= 0; i--)
    {
        printf(" %d | %c | %c | %c | %c | %c | %c | %c | %c |      %d | %c | %c | %c | %c | %c | %c | %c | %c |\n", i + 1, kodyfigurek[6 + sz.pola[i][0]], kodyfigurek[6 + sz.pola[i][1]], kodyfigurek[6 + sz.pola[i][2]], kodyfigurek[6 + sz.pola[i][3]], kodyfigurek[6 + sz.pola[i][4]], kodyfigurek[6 + sz.pola[i][5]], kodyfigurek[6 + sz.pola[i][6]], kodyfigurek[6 + sz.pola[i][7]], i + 1, kodyfigurek[6 + sz2.pola[i][0]], kodyfigurek[6 + sz2.pola[i][1]], kodyfigurek[6 + sz2.pola[i][2]], kodyfigurek[6 + sz2.pola[i][3]], kodyfigurek[6 + sz2.pola[i][4]], kodyfigurek[6 + sz2.pola[i][5]], kodyfigurek[6 + sz2.pola[i][6]], kodyfigurek[6 + sz2.pola[i][7]]);
        printf("   +---+---+---+---+---+---+---+---+        +---+---+---+---+---+---+---+---+\n");
    }
    printf("     A   B   C   D   E   F   G   H            A   B   C   D   E   F   G   H\n\n");
    printf("    Roszady: %c%c%c%c, Ep: %s, Ruch: %c          Roszady: %c%c%c%c, Ep: %s, Ruch: %c\n\n", sz.biale_dluga ? 'Q' : '-', sz.biale_krotka ? 'K' : '-', sz.czarne_dluga ? 'q' : '-', sz.czarne_krotka ? 'k' : '-', sz.bicie_w_locie ? polastr[sz.bicie_w_locie->wiersz][sz.bicie_w_locie->kolumna] : "nie", sz.ruch == bialy ? 'W' : 'B', sz2.biale_dluga ? 'Q' : '-', sz2.biale_krotka ? 'K' : '-', sz2.czarne_dluga ? 'q' : '-', sz2.czarne_krotka ? 'k' : '-', sz2.bicie_w_locie ? polastr[sz2.bicie_w_locie->wiersz][sz2.bicie_w_locie->kolumna] : "nie", sz2.ruch == bialy ? 'W' : 'B'  );
}

void ruch2txt(ruch *r)
{
    sprintf(r->txt, "%s%s%c", polastr[r->z.wiersz][r->z.kolumna], polastr[r->na.wiersz][r->na.kolumna], !r->promocja ? 0 : kodyfigurek[6 + r->promocja * (r->promocja > 0 ? 1 : -1)]);
}

#endif