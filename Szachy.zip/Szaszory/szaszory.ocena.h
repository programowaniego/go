#ifndef SZASZORY_OCENA

#define SZASZORY_OCENA
#include<limits.h>
#include "szaszory.definicje.h"
#include "szaszory.generator.ruchow.h"

int ocena(szachownica *sz)
{
    pole *mojkrol = NULL, *krolprzeciwnika = NULL;
    for(int wiersz = 0; wiersz < 8; wiersz++)
        for(int kolumna = 0; kolumna < 8; kolumna++)
            switch(sz->pola[wiersz][kolumna] * sz->ruch)
            {
                case bialy_krol:
                    mojkrol = &pola[wiersz][kolumna];
                    break;
                case czarny_krol:
                    krolprzeciwnika = &pola[wiersz][kolumna];
            }
    if (!mojkrol)
        // Nie ma mojego krola! Przegrana!!!
        return -1000000;
    if (!krolprzeciwnika || czyktosatakuje(sz, krolprzeciwnika, sz->ruch))
        // Nie ma krola przeciwnika lub istnieje mozliwosc zbicia krola przeciwnika
        return 1000000;
    return 0;
}

boolean czykoniecgry(szachownica *sz)
{
    pole *mojkrol = NULL, *krolprzeciwnika = NULL;
    for(int wiersz = 0; wiersz < 8; wiersz++)
        for(int kolumna = 0; kolumna < 8; kolumna++)
            switch(sz->pola[wiersz][kolumna] * sz->ruch)
            {
                case bialy_krol:
                    mojkrol = &pola[wiersz][kolumna];
                    break;
                case czarny_krol:
                    krolprzeciwnika = &pola[wiersz][kolumna];
            }
    return (!mojkrol || !krolprzeciwnika); 
}

boolean sprawdzszachownice(szachownica *sz)
{
    pole *krolbialy = NULL, *krolczarny = NULL;
    for(int wiersz = 0; wiersz < 8; wiersz++)
        for(int kolumna = 0; kolumna < 8; kolumna++)
            switch(sz->pola[wiersz][kolumna])
            {
                case pusta:
                    break;
                case bialy_krol:
                    if (!krolbialy)
                        krolbialy = & pola[wiersz][kolumna];
                    else 
                        return falsz;
                    break;
                case czarny_krol:
                    if (!krolczarny)
                        krolczarny = & pola[wiersz][kolumna];
                    else 
                        return falsz;
                    break;
                case bialy_pionek:
                case czarny_pionek:
                case bialy_skoczek:
                case czarny_skoczek:
                case bialy_goniec:
                case czarny_goniec:
                case bialy_hetman:
                case czarny_hetman:
                case bialy_wieza:
                case czarny_wieza:
                    break;
                default:
                    return falsz;
            }
    if (krolbialy)
    {
        if (krolbialy->wiersz == 0 && krolbialy->kolumna == 4)
        {
            if (sz->biale_krotka && sz->pola[0][7] != bialy_wieza)
                return falsz;
            if (sz->biale_dluga && sz->pola[0][0] != bialy_wieza)
                return falsz;
        }
        else
            if (sz->biale_krotka || sz->biale_dluga)
                return falsz;
    }
    else
        return falsz;
    if (krolczarny)
    {
        if (krolczarny->wiersz == 7 && krolczarny->kolumna == 4)
        {
            if (sz->czarne_krotka && sz->pola[7][7] != czarny_wieza)
                return falsz;
            if (sz->czarne_dluga && sz->pola[7][0] != czarny_wieza)
                return falsz;
        }
        else
            if (sz->czarne_krotka || sz->czarne_dluga)
                return falsz;
    }
    else
        return falsz;
    return prawda;
}

#endif