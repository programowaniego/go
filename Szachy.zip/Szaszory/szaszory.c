
#define DEBUG
#define PISZ_WARIANTY

#include<stdio.h>
#include"szaszory.definicje.h"
#include"szaszory.fen.h"
#include"szaszory.lista.ruchow.h"
#include"szaszory.generator.ruchow.h"
#include"szaszory.wykonywanie.ruchow.h"
#include"szaszory.alfa.beta.h"
#include<time.h>

void main()
{
    //szachownica sz = ustawFEN("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq a3");
    //szachownica sz = ustawFEN("1nbqkbnr/PpPpp1pp/8/2B1PpP1/2q1Q3/3P4/PPP1pPPP/RNBQKBNR w KQkq f6");
    //szachownica sz = ustawFEN("r2qk2r/1ppbbppp/2n1pn2/pP1p4/2PP2pP/1QN2NP1/Pp1BPPB1/R3K2R b KQkq h3");
    //szachownica sz = ustawFEN("2R3k1/5ppp/8/8/8/8/8/3K4 b - -");
    szachownica sz = ustawFEN("6k1/5ppp/8/8/8/8/8/2RK4 w - -");
    /*listaruchow *lr = generujruchy(&sz), *ptr = lr;
    while (ptr)
    {
        ruch2txt(&ptr->r);
        szachownica sz2 = wykonajruch(&sz, &ptr->r);
        printf("***** %s = %d *****\n", ptr->r.txt, alfabeta(&sz2, 0, INT_MIN, INT_MAX, NULL));  
        wypisz2(sz, sz2);
        ptr = ptr->nast;
    }
    printf("\n\n");
    zniszczliste(lr);
    */
    printf("************************************\n");
    printf("************************************\n");
    printf("************************************\n");
    clock_t start = clock();
    int ocena = alfabeta(&sz, 2, -1000000, 1000000, NULL);
    clock_t stop = clock();
    printf("\nOcena = %d : %f s\n", ocena, 1.0 * (stop - start) / CLOCKS_PER_SEC);
    wypisz(sz);
}