#ifndef SZASZORY_WYKONYWANIE_RUCHOW

#define SZASZORY_WYKONYWANIE_RUCHOW
#include <assert.h>
#include "szaszory.generator.ruchow.h"
#include "szaszory.ocena.h"

void wypiszwariant(listaruchow *wariant)
{
    while(wariant)
    {
        ruch2txt(&wariant->r);
        printf("%s ", wariant->r.txt);
        wariant = wariant->nast;
    }
    printf("\n");
}

szachownica wykonajruch(szachownica *sz, ruch *r)
{
    //assert(sprawdzszachownice(sz));

    szachownica nowa = *sz;

    nowa.pola[r->na.wiersz][r->na.kolumna] = nowa.pola[r->z.wiersz][r->z.kolumna];
    nowa.pola[r->z.wiersz][r->z.kolumna] = pusta;

    // Czy to jest roszada?
    if (r->z.wiersz == (nowa.ruch == bialy ? 0 : 7) && r->na.wiersz == (nowa.ruch == bialy ? 0 : 7) && r->z.kolumna == 4 && r->na.kolumna == 2 && nowa.pola[r->z.wiersz][r->na.kolumna] == nowa.ruch * bialy_krol)
    {
        nowa.pola[r->z.wiersz][(r->na.kolumna == 6) ? 5 : 3] = nowa.pola[r->z.wiersz][(r->na.kolumna == 6) ? 7 : 0];
        nowa.pola[r->z.wiersz][(r->na.kolumna == 6) ? 7 : 0] = pusta;
        
        if (nowa.ruch == bialy)
            nowa.biale_dluga = nowa.biale_krotka = falsz;
        else
            nowa.czarne_dluga = nowa.czarne_krotka = falsz;
    }
    // Czy to jest bicie w locie?
    if (nowa.bicie_w_locie && r->na.wiersz == nowa.bicie_w_locie->wiersz && r->na.kolumna == nowa.bicie_w_locie->kolumna && nowa.pola[r->na.wiersz][r->na.kolumna] == bialy_pionek * nowa.ruch)
        nowa.pola[r->z.wiersz][r->na.kolumna] = pusta;
    nowa.bicie_w_locie = NULL;
    // Czy to jest promocja?
    if (r->promocja)
        nowa.pola[r->na.wiersz][r->na.kolumna] = r->promocja;
    // Czy to jest ruch pionka o 2 do przodu?
    if (nowa.pola[r->na.wiersz][r->na.kolumna] * nowa.ruch == bialy_pionek && abs(r->na.wiersz - r->z.wiersz) == 2)
        nowa.bicie_w_locie = &pola[(r->z.wiersz + r->na.wiersz) / 2][r->z.kolumna];
    // Jeśli nastepuje ruch wieżą, to trzeba zaktualizować roszady
    if (nowa.pola[r->na.wiersz][r->na.kolumna] * nowa.ruch == bialy_krol)
    {
        if (nowa.ruch == bialy)
            nowa.biale_dluga = nowa.biale_krotka = falsz;
        else
            nowa.czarne_dluga = nowa.czarne_krotka = falsz;
    }
    // Jeśli następuje ruch wieżą, to trzeba zaktualizować roszady
    if (nowa.pola[r->na.wiersz][r->na.kolumna] * nowa.ruch == bialy_wieza)
    {
        if (nowa.ruch == bialy)
            switch(r->z.kolumna)
            {
                case 0:
                    nowa.biale_dluga = falsz;
                    break;
                case 7:
                    nowa.biale_krotka = falsz;
                    break;
            }
        else
            switch(r->z.kolumna)
            {
                case 0:
                    nowa.czarne_dluga = falsz;
                    break;
                case 7:
                    nowa.czarne_krotka = falsz;
                    break;
            }
    }
    nowa.ruch = (kolorek)(-nowa.ruch);
    //assert(sprawdzszachownice(sz));
    return nowa;
}

#endif