#ifndef SZASZORY_ALFA_BETA

#define SZASZORY_ALFA_BETA
#include "szaszory.ocena.h"
#include "szaszory.generator.ruchow.h"
#include "szaszory.wykonywanie.ruchow.h"

/*
int alfaBeta(stan s, int glebokosc, int alfa, int beta)
{
    if (is_terminal_node(s) || glebokosc == 0)
        return(Eval(s, glebokosc));
    for(child=1; child<=NumOfSucc(s); child++) 
    {
        val = -alfaBeta(Succ(s, child), glebokosc - 1, -beta, -alfa);
        if(val > alfa) 
            alfa = val; // alfa=max(val,alfa);
        if(alfa >= beta) 
            return beta; // cutoff
    }
    return alfa;
}
*/

int alfabeta(szachownica *s, int glebokosc, int alfa, int beta, listaruchow *wariant)
{
    if (czykoniecgry(s) || glebokosc == 0)
        return(ocena(s));
    listaruchow *l = generujruchy(s);
    for(; l; l = (listaruchow *)l->nast) 
    {
#ifdef PISZ_WARIANTY
        wariant = dodajruch(wariant, l->r);
#endif
        szachownica dziecko = wykonajruch(s, &l->r);
        int val = -alfabeta(&dziecko, glebokosc - 1, -beta, -alfa, wariant);
#ifdef DEBUG
        printf("%8d : ", val); 
        wypiszwariant(wariant);
#endif
#ifdef PISZ_WARIANTY
        wariant = zniszczostatni(wariant);
#endif
        if (val > alfa) 
        {
            alfa = val; // alfa=max(val,alfa);
        }
        if (alfa >= beta) 
        {
            zniszczliste(l);
            return beta; // cutoff
        }
        
    }
    zniszczliste(l);
    return alfa;
}

int alfabetapocalosci(szachownica *s, int glebokosc, int alfa, int beta, listaruchow *wariant)
{
    if (czykoniecgry(s) || glebokosc == 0)
        return(ocena(s));
    listaruchow *l = generujruchy(s);
    for(; l; l = (listaruchow *)l->nast) 
    {
        szachownica dziecko = wykonajruch(s, &l->r);
        int val = -alfabetapocalosci(&dziecko, glebokosc - 1, -1000000, 1000000, wariant);
        if (val > alfa) 
            alfa = val; // alfa=max(val,alfa);
        if (alfa >= beta) 
        {
            zniszczliste(l);
            return beta; // cutoff
        }
    }
    zniszczliste(l);
    return alfa;
}

#endif