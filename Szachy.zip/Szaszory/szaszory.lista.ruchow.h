#ifndef SZASZORY_LISTA_RUCHOW

#define SZASZORY_LISTA_RUCHOW
#include<stdlib.h>
#include "szaszory.definicje.h"

typedef struct 
{
    ruch r;
    void* nast;
} listaruchow;

listaruchow* dodajruch(listaruchow *l, ruch r)
{
    listaruchow *x = (listaruchow *)calloc(1, sizeof(listaruchow));
    x->r = r;
    x->nast = NULL;
    if (!l)
        return x;
    listaruchow *glowa = l;
    while(l->nast)
        l = (listaruchow *)l->nast;
    l->nast = x;
    return glowa;
}

listaruchow* zniszczostatni(listaruchow *l)
{
    listaruchow *ptr = l, *poprz = NULL;
    for(; ptr && ptr->nast; poprz = ptr, ptr = ptr->nast);
    if (poprz)
        poprz->nast = NULL;
    free(ptr);
    return ptr == l ? NULL : l;
}

void zniszczliste(listaruchow *l)
{
    if (l && l->nast)
        zniszczliste((listaruchow *)l->nast);
    if (l)
        free(l);
}

#endif